﻿//C++17
#include <iostream>
#include <fstream>
#include <string>
#include "HTMLcreator.h"
#include "FilesStructure.h"
#include "ControlPanel.h"
#include <filesystem>


int main()
{
	greeting();
	panel();
}



