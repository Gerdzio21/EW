#ifndef ControlPanel_H
#define ControlPanel_H

#include<string>
#include "FilesStructure.h"

void greeting();
void panel ();

#endif // !

